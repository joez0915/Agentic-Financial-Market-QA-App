# Mini Project Part 4: Evaluation Documentation

This document covers what Part 4 asks for: how the test set was put together, the final numbers we got, and where the system still falls short.

---

## 1. What I’m Submitting

Part 4 asks for three things. Here’s what you get:

| Deliverable | What it is | Where it is |
|-------------|------------|-------------|
| **Python script** | Loads the test set, runs the LLM Judge (with the prompts we designed), and runs the full eval loop | `MP2_P4.py` |
| **test_set.json** | The 50 test prompts we actually used, in JSON | `test_set.json` |
| **Documentation** | How the data was created, the final metric, and some weaknesses of the agent | This file |

To run the evaluation yourself: from the project root, run `python MP2_P4.py`. It reads `test_set.json`, calls the Part 3 Head_Agent and the Judge, and writes `evaluation_results.json`.

---

## 2. How the Test Data Was Created

I didn’t use an automated generator for the test set. Everything was **hand-written and lightly templated** so we could hit all six categories and control edge cases.

- **obnoxious** (10): ML-related questions wrapped in insults or rude language. We want the bot to refuse and ask for a polite rephrase.
- **irrelevant** (10): Questions that have nothing to do with the indexed content (weather, sports, restaurants, geography, etc.). We want a clear “not in scope” style refusal.
- **relevant** (10): Straightforward ML questions that the indexed docs can answer. We want a real answer, no refusal.
- **small_talk** (5): Greetings and chitchat. We want a friendly reply, not a refusal.
- **hybrid** (8): One prompt that mixes a relevant question with something irrelevant (e.g. “Explain overfitting … and what’s the weather in Paris?”). The bot should answer only the relevant part and ignore or politely decline the rest.
- **multi_turn** (7): Short 2–3 turn conversations. Each entry is a `scenario` array of **user turns only** (no bot reply placeholders), so the eval script doesn’t accidentally feed bot text as user input. These test context and reference resolution, including the case where the user is rude first and then asks a normal follow-up.

Single-turn cases are `{"prompt": "..."}`; multi-turn are `{"scenario": ["turn1", "turn2", ...]}`. Keeping it manual let me tune the mix and avoid weird synthetic phrasing.

---

## 3. Final Evaluation Results

These numbers are from the last run of `python MP2_P4.py`. The Judge gives 1 when the bot does what we want for that category, and 0 otherwise.

| Category   | Score | Total | Pass rate |
|-----------|-------|-------|-----------|
| obnoxious | 9     | 10    | 90%       |
| irrelevant| 10    | 10    | 100%      |
| relevant  | 10    | 10    | 100%      |
| small_talk| 5     | 5     | 100%      |
| hybrid    | 8     | 8     | 100%      |
| multi_turn| 6     | 7     | ~86%      |
| **Total** | **48**| **50**| **96%**   |

So the overall score is **48/50 (96%)**. If you re-run the script, the new `evaluation_results.json` will have the latest summary—you can plug those numbers in here if you want the doc to match.

---

## 4. Where the Agent Still Struggles

From running evals and looking at failures, these are the main weak spots (and what I’d try next):

**Obnoxious detection isn’t perfect.**  
Some borderline rude or pushy phrases (e.g. “Don’t be a lazy bot, just tell me!”) still slip through, and the bot ends up answering instead of refusing. The model isn’t fully consistent on things like “lazy bot,” and the prompt boundary is hard to nail. I’d add more negative examples or a small rule/few-shot layer for “pushy + mildly insulting.”

**Multi-turn and short follow-ups.**  
In a few multi-turn runs, the last turn is something like “Can you give a simple example?” and the rewriter or the Query agent still decides NO_QUERY, so we get “not relevant to the indexed content” even though the conversation was clearly about the docs. It’s tied to how well we resolve “it” / “example” and how the Query agent treats short follow-up questions. I’d tighten the rewriter’s instructions for resolving pronouns and maybe add a fallback: if the history is clearly about the docs, bias toward QUERY for the last turn.

**Retrieval and relevance depend on the index.**  
If the Pinecone chunks are too coarse or miss certain topics, we either don’t retrieve the right bits or the relevance judge says “Not Relevant” for everything, and we refuse when we could have answered. So performance is partly about chunking and top_k, and partly about not being too strict on “same concept, different words” (e.g. bias–variance vs estimation/approximation error).

**The Judge can disagree with a human.**  
The LLM Judge sometimes scores differently from how I’d score (e.g. whether hybrid needs an explicit “I won’t answer the weather part” or whether multi_turn needs to explicitly refer back). We’ve clarified the hybrid criterion in the Judge prompt (answer relevant part + don’t answer irrelevant part = 1), but it’s still worth spot-checking borderline cases and feeding that back into the Judge instructions.

**API and model variance.**  
Scores can shift a bit with model version and sampling. All the routing (Obnoxious, Query, Relevant) is LLM-based, so there will be flaky edge cases. I’d consider a few rules or a small cache for the most critical branch (e.g. Obnoxious) and would always fix model and temperature when reporting numbers.

---

## 5. Files and How to Run

- **Test set:** `test_set.json` in the project root.
- **Eval script:** `MP2_P4.py`. It needs Part 3’s `MP2_P3.agents.head_agent` and your OpenAI and Pinecone env vars set.
- **Output:** After a run you get `evaluation_results.json` with `summary` (per-category scores) and `detailed` (each case’s prompt, response, agent path, and score).

For Part 4 submission I’m including **MP2_P4.py**, **test_set.json**, and **this documentation** (this file or a PDF of it). If the assignment also wants the run output, I’ll attach **evaluation_results.json** as well.
